package com.example.hello.dataSet;

public class Student {
	
	private String stuName;
	private String stuRollno;
	private String stuAddress;
	private String stuCourse;
	
	public Student() {
		
	}
	
	public Student(String stuName,String stuRollno,String stuAddress,String stuCourse) {
		//super();
		this.stuName=stuName;
		this.stuRollno=stuRollno;
		this.stuAddress=stuAddress;
		this.stuCourse=stuCourse;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuRollno() {
		return stuRollno;
	}

	public void setStuRollno(String stuRollno) {
		this.stuRollno = stuRollno;
	}

	public String getStuAddress() {
		return stuAddress;
	}

	public void setStuAddress(String stuAddress) {
		this.stuAddress = stuAddress;
	}

	public String getStuCourse() {
		return stuCourse;
	}

	public void setStuCourse(String stuCourse) {
		this.stuCourse = stuCourse;
	}

	@Override
	public String toString() {
		return "Student [stuName=" + stuName + ", stuRollno=" + stuRollno + ", stuAddress=" + stuAddress
				+ ", stuCourse=" + stuCourse + "]";
	}
	
	
}
