package com.example.hello.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.hello.dataSet.Student;
import com.example.hello.serviceimpl.Studentimpl;

import jakarta.websocket.server.PathParam;

@RestController
public class StudentController {
	
	@Autowired
	private Studentimpl studentimpl;
	
	@GetMapping(value = "/div")
	public Integer division(@PathParam ("fno") Integer fno,@PathParam ("sno") Integer sno)
	{
		return studentimpl.division(fno,sno);
	}
	
	
	@GetMapping("/createDataSet")
	public String saveUpdateStudentData() {
		studentimpl.createDataSet();
		return "All Employee Data is ready";
	}
	
	
	@GetMapping("/getAllStudent")	// This is for get All student records
	public List<Student> getAllStudent()
	{
		return studentimpl.getAllStudent();
	}
	
	
	@PostMapping("/saveStudent")	// save single student data
	public String saveStudent(@RequestBody Student student) 
	{
		return studentimpl.saveStudent(student);
	}
	
	
	@GetMapping("/getStudent/{stuRollno}")	// This is for get single student record
	public Student getStudent(@PathVariable("stuRollno") String stuRollno) 
	{
		return studentimpl.singleStudent(stuRollno);
	}
	
	
	@PutMapping("/updateStudent/{stuRollno}")	// update single student
	public String updateStudent(@RequestBody Student student,@PathVariable("stuRollno") String stuRollno) 
	{	
		 return studentimpl.updateData(student,stuRollno);
	}
	
	
	@DeleteMapping("/deleteStudent/{stuRollno}")	// delete single student records
	public String deletestudent(@PathVariable("stuRollno") String stuRollno)
	{
		return studentimpl.deleteStudent(stuRollno);
	}
	
	
	@DeleteMapping("/deleteAllStudent")
	public String deleteAll() // delete all student records
	{
		return studentimpl.deleteAllStudent();
	}
}
