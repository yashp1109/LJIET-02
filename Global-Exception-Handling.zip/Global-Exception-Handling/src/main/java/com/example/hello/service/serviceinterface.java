package com.example.hello.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.hello.dataSet.Student;

@Service
public interface serviceinterface 
{	
	public Integer division(Integer a, Integer b);
	
	public void createDataSet();
	
	public List<Student> getAllStudent();
	
	public String saveStudent(Student stu);
	
	public Student singleStudent(String stuRollno);
	
	public Student getStudent(String Rollno);
	
	public String updateData(Student student, String stuRollno);
	
	public String deleteStudent(String stuRollno);
	
	public String deleteAllStudent();
	
	

}
