package com.example.hello.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	Date d1 = new Date(); 
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<FormatException> exceptionThird(Exception e) 
	{	
		return new ResponseEntity<FormatException>(new FormatException("Please Entered second value", "5000",d1),HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(ArithmeticException.class)
	public ResponseEntity<?> exceptionFirst(ArithmeticException e)
	{
		FormatException exception = new FormatException(e.getMessage(),"1000",d1);
		return new ResponseEntity<FormatException> (exception,HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<FormatException> exceptionSecond(CustomException e) 
	{
		return new ResponseEntity<FormatException>(new FormatException(e.getMessage(), e.getCode(),d1),HttpStatus.BAD_REQUEST);
	}

	
}
