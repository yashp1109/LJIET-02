package com.example.hello.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.hello.dataSet.Student;
import com.example.hello.exceptions.CustomException;
import com.example.hello.service.serviceinterface;

@Component
public class Studentimpl implements serviceinterface {
	
//	@Override
//	public Integer division(Integer a, Integer b) {
//		Integer c = a / b;
//		return c;
//	}
	
	
	@Override
	public Integer division(Integer a, Integer b) {
		if (b <= 0) {
			throw new CustomException("Invalid 2nd Number", "2000");
		}
		Integer c = a / b;
		return c;
	}
	
	List<Student> stulist = new ArrayList<>();
	
	public void createDataSet() 
	{
		
		Student s1=new Student();
		s1.setStuName("Jayraj");
		s1.setStuRollno("101");
		s1.setStuAddress("Amreli");
		s1.setStuCourse("MCA");
		
		Student s2=new Student("Hiren","201","Dhari","BCA");
		Student s3=new Student("Nikunj","301","Rajkot","BBA");
		Student s4=new Student("Kunjan","401","Ahmedabad","B.COM");
		Student s5=new Student("Yuvraj","501","Surat","MCA");
		
		stulist.add(s1);
		stulist.add(s2);
		stulist.add(s3);
		stulist.add(s4);
		stulist.add(s5);
	}
	
	
	public List<Student> getAllStudent()
	{
		return stulist;
	}
	
	
	public String saveStudent(Student stu) 
	{
		stulist.add(stu);
		return "Data Saved Successfully";
	}
	
	
	public Student singleStudent(String stuRollno)
	{
//		for(Student x:stulist)
//		{
//			if(x.getStuRollno().equals(stuRollno))
//			{
//				return x;	
//			}
//		}
//		return null;
		
		Student stu=stulist.stream()
							.filter(stulist->stuRollno.equals(stulist.getStuRollno()))
							.findAny()
							.orElse(null);	
					return stu;
	}
	
	
	
	
	public Student getStudent(String Rollno) 
	{	
		for(Student x:stulist) 
		{
			if(Rollno.equals(x.getStuRollno()))
			{
				return x;
			}
		}
		return null;
	}
	
	
	public String updateData(Student student, String stuRollno)
	{
//		for(Student x:stulist)
//		{
//			if(stu.getStuRollno().equals(x.getStuRollno()))
//			{
//				x.setStuName(stu.getStuName());
//				x.setStuAddress(stu.getStuAddress());
//				x.setStuCourse(stu.getStuCourse());
//				
//				return "Data Updated Successfully";
//			}
//		}
//		return "Data not found";
		
				List<Student> stu1=stulist.stream().filter(s ->stuRollno.equals(s.getStuRollno())).collect(Collectors.toList());
			
				if(!stu1.isEmpty())
				{
					Student s1= stu1.get(0);
					s1.setStuName(student.getStuName());
					s1.setStuAddress(student.getStuAddress());
					s1.setStuCourse(student.getStuCourse());
					
				}
				return "Update Successfully";
	}
	
	
	public String deleteStudent(String stuRollno)
	{
//		for(Student x:stulist)
//		{
//			if(stuRollno.equals(x.getStuRollno()))
//			{
//				stulist.remove(x);
//				return "Data is remove";	
//			}
//		}
//		return "Data is not found";
		
		Student stu=stulist.stream()
				.filter(stulist->stuRollno.equals(stulist.getStuRollno()))
				.findAny()
				.orElse(null);	
		stulist.remove(stu);
		return "Data remove success";
		
	}
	
	
	public String deleteAllStudent()
	{
		stulist.clear();
		return "Remove All";
	}


}