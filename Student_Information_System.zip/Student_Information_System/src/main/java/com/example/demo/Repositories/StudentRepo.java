package com.example.demo.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Entities.Student;

@Repository
public interface StudentRepo extends JpaRepository<Student, String> {

//	@Query(value="select * from student where enrollmentNo=rollno",nativeQuery = true)
//	Student findName(@Param("rollno") String rollno);
}
