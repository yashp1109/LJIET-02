package com.example.demo.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Proxies.EducationDetailsDTO;
import com.example.demo.Proxies.FeeDetailsDTO;
import com.example.demo.Proxies.StudentDTO;
import com.example.demo.Services.EducationDetailsServices;
import com.example.demo.Services.FeeDetailsServices;
import com.example.demo.Services.StudentServices;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private StudentServices studentServices;
	
	@Autowired
	private FeeDetailsServices feeDetailsServices;
	
	@Autowired
	private EducationDetailsServices educationService;
	
	// *************************************** Signup API **********************************************	
	
	@PostMapping("/register") 
	public ResponseEntity<String> registerWithDetails(@RequestBody StudentDTO studentDTO)
	{
		return new ResponseEntity<String>(studentServices.UserRegistration(studentDTO),HttpStatus.ACCEPTED);
	}

		// *************************************** Update API **********************************************	
	
	@PostMapping("/updateUser")
	public ResponseEntity<String> updateUserDetails(@RequestBody StudentDTO studentDTO)
	{
		return new ResponseEntity<String>(studentServices.updateUser(studentDTO),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Get API **********************************************	
	
	@GetMapping("/getUser/{enrollmentNo}")
	public ResponseEntity<StudentDTO> getUser(@PathVariable String enrollmentNo)
	{
		return new ResponseEntity<StudentDTO>(studentServices.getUser(enrollmentNo),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Get FeeDetails API **********************************************
	
	@GetMapping("/getFeeDetails/{id}")
	public ResponseEntity<FeeDetailsDTO>  getFeeDetails(@PathVariable("id") Long id)
	{
		return new ResponseEntity<FeeDetailsDTO>(feeDetailsServices.getFeeDetails(id),HttpStatus.ACCEPTED);
	}
		
	// ***************************************	Add EducationDetails API **********************************************
	
	@PostMapping("/addEducationDetails")
	public ResponseEntity<String> addEducationDetails(@RequestBody EducationDetailsDTO educationdetailsDto )
	{
		return new ResponseEntity<String>(educationService.addEducationDetail(educationdetailsDto),HttpStatus.ACCEPTED);
	}
	
	// ***************************************	Update EducationDetails API **********************************************
	
	@PostMapping("/updateEducationDetails")
	public ResponseEntity<String> updateEducationDetails(@RequestBody EducationDetailsDTO EducationDetailsDTO)
	{
		return new ResponseEntity<String>(educationService.updateEducationDetails(EducationDetailsDTO),HttpStatus.ACCEPTED);
	}
}
