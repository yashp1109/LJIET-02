package com.example.demo.Exceptions;

import java.util.Date;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.SignatureException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	Date d1=new Date();
	
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity<FormatException> exception(NoSuchElementException e)
	{
		return new ResponseEntity<FormatException>(new FormatException("id is not present","4000",d1.toString()),HttpStatus.BAD_REQUEST);
	}
	
	

	
}
