package com.example.demo.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ProjectUserDetails.ProjectUserDetails;
import com.example.demo.Utils.JwtUtils;
import com.example.demo.reqres.LoginRequest;
import com.example.demo.reqres.LoginResponse;


@RestController
@RequestMapping("/auth")
public class AuthController {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtUtils jwtUtils;
	
	@Autowired
	private ProjectUserDetails userDetails;
	
// *************************************** Login API **********************************************	
	
	@PostMapping("/login")
	public ResponseEntity<LoginResponse> loginWithCredentials(@RequestBody LoginRequest request)
	{
		
		
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getEnrollmentNo(), request.getPassword()));

		} catch (Exception e) {
			e.printStackTrace();
		}
	
		userDetails.setRole(request.getRole());
		
		//Generate JWT token
		UserDetails userdtls=userDetails.loadUserByUsername(request.getEnrollmentNo());

		String token=jwtUtils.generateToken(userdtls);
		
		return new ResponseEntity<LoginResponse>(new LoginResponse(token),HttpStatus.OK);
	}
	
	
// *************************************** Validate API **********************************************	
	
	@PostMapping("/validate")
	public ResponseEntity<String> ValidateToken()
	{
		return new ResponseEntity<String> ("JWT Token Working",HttpStatus.ACCEPTED);
	}

}
