package com.example.demo.Services;

import org.springframework.stereotype.Service;

import com.example.demo.Proxies.EducationDetailsDTO;

@Service
public interface EducationDetailsServices {

	public String addEducationDetail(EducationDetailsDTO educationDetailsDTO);
	
	public String updateEducationDetails(EducationDetailsDTO educationDetailsDTO);
	
	public EducationDetailsDTO getEducationDetails(Long id);
}
