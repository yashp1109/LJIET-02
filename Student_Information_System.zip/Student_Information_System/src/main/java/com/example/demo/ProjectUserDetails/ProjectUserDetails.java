package com.example.demo.ProjectUserDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Entities.Administartor;
import com.example.demo.Entities.CustomAdministrator;
import com.example.demo.Entities.CustomUser;
import com.example.demo.Entities.Role;
import com.example.demo.Entities.Student;
import com.example.demo.Repositories.AdministartorRepo;
import com.example.demo.Repositories.StudentRepo;

@Service
public class ProjectUserDetails implements UserDetailsService{

	@Autowired
	private StudentRepo studentRepo;
	
	@Autowired
	private AdministartorRepo adminRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	private String role;
	
	public void setRole(String role) {
		// TODO Auto-generated method stub
		this.role = role;
	}
	
	
	@Override
	public UserDetails loadUserByUsername(String rollno){

		
		if (role.equals(Role.ROLE_ADMIN.toString())) {

	 
			Administartor admin = adminRepo.findById(Long.parseLong(rollno)).get();
	 
				if (admin != null) {
			
					return new CustomAdministrator(admin);
				} else {
					throw new UsernameNotFoundException("Admin name is invalid");
				}
	 
			}
		
		else if(role.equals(Role.ROLE_USER.toString())) {

				Student student = studentRepo.findById(rollno).get();
	 
				if (student != null) {
					
					return new CustomUser(student);
					
				} 
				else 
				{
					throw new UsernameNotFoundException("User name is invalid");
				}
	 
			}
	 
	else {
		System.out.println("Select Your Role Propurly..!!");
		return null;
	}
	 
	}

	

}
