package com.example.demo.ServiceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Entities.FeeDetails;
import com.example.demo.Proxies.FeeDetailsDTO;
import com.example.demo.Repositories.FeeDetailsRepo;
import com.example.demo.Services.FeeDetailsServices;
import com.example.demo.Utils.ObjectMapperHelper;

@Component
public class FeeDetailsServicesImpl implements FeeDetailsServices{

	@Autowired
	private FeeDetailsRepo repo;
	
	@Autowired
	private ObjectMapperHelper helper;
	
	@Override
	public FeeDetailsDTO getFeeDetails(Long id) {

		Optional<FeeDetails> byId = repo.findById(id);
		
		if(byId.isPresent())
		{
			FeeDetailsDTO feeDetails = helper.FeeDetailsEntityToDto(byId.get());
			return feeDetails;
		}
		
		return null;
				
	}

	@Override
	public String addFeeDetails(FeeDetailsDTO feeDetailsDTO) {

		FeeDetails feeDetails= helper.FeeDetailsDtoToEntity(feeDetailsDTO);
		
		repo.save(feeDetails);
		
		return "Detail saved Successfully";
		
	}

}
