package com.example.demo.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Proxies.AdministartorDTO;
import com.example.demo.Proxies.EducationDetailsDTO;
import com.example.demo.Proxies.FeeDetailsDTO;
import com.example.demo.Proxies.StudentDTO;
import com.example.demo.Services.AdministartorServices;
import com.example.demo.Services.EducationDetailsServices;
import com.example.demo.Services.FeeDetailsServices;
import com.example.demo.Services.StudentServices;

@RestController
@RequestMapping("/admin")
public class AdministrativeController {

	@Autowired
	private AdministartorServices adminService;
	
	@Autowired
	private FeeDetailsServices feeDetailsServices;
	
	@Autowired
	private StudentServices studentServices;
	
	@Autowired
	private EducationDetailsServices educationServices;
	
	// *************************************** Signup API **********************************************	
	
	@PostMapping("/register")
	public ResponseEntity<String> registerWithDetails(@RequestBody AdministartorDTO administartorDTO)
	{
		System.err.println("Hii");
		return new ResponseEntity<String> (adminService.AdminRegistration(administartorDTO),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Update User API **********************************************		
	
	@PostMapping("/updateUser")
	public ResponseEntity<String> updateUserDetails(@RequestBody StudentDTO studentDTO)
	{
		return new ResponseEntity<String>(studentServices.updateUser(studentDTO),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Update Admin API **********************************************	
	
	@PostMapping("/updateAdmin")
	public ResponseEntity<String> updateAdminDetails(@RequestBody AdministartorDTO administartorDTO)
	{
		return new ResponseEntity<String> (adminService.UpdateAdmin(administartorDTO),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Delete User AP **********************************************	
	
	@PostMapping("/deleteUser/{enrollmentNo}")
	public ResponseEntity<String> deleteUser(@PathVariable String enrollmentNo)
	{
		return new ResponseEntity<String>(adminService.deleteUserById(enrollmentNo),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Get Users API **********************************************	
	
	@GetMapping("/getAllUser")
	public ResponseEntity<List<StudentDTO>> getUsers()
	{
		return new ResponseEntity<List<StudentDTO>>(adminService.getAllUser(),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Get User API **********************************************	
	
	@GetMapping("/getUser/{enrollmentNo}")
	public ResponseEntity<StudentDTO> getUser(@PathVariable String enrollmentNo)
	{
		return new ResponseEntity<StudentDTO>(studentServices.getUser(enrollmentNo),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Get Admin API **********************************************	
	
	@GetMapping("/getAdmin/{id}")
	public ResponseEntity<AdministartorDTO> getAdmin(@PathVariable("id") Long id)
	{
		return new ResponseEntity<AdministartorDTO>(adminService.getAdmin(id),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Add FeeDetails API **********************************************	
	
	@PostMapping("/addFeeDetails")
	public ResponseEntity<String> addFeeDetails(@RequestBody FeeDetailsDTO feeDetailsDTO)
	{
		return new ResponseEntity<String>(feeDetailsServices.addFeeDetails(feeDetailsDTO),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Get FeeDetails API **********************************************
	
	@GetMapping("/getFeeDetails/{id}")
	public ResponseEntity<FeeDetailsDTO> getFeeDetails(@PathVariable Long id)
	{
		return new ResponseEntity<FeeDetailsDTO>(feeDetailsServices.getFeeDetails(id),HttpStatus.ACCEPTED);
	}
	
	// *************************************** Get EducationDetails API **********************************************
	
	@GetMapping("/getEducationDetails/{id}")
	public ResponseEntity<EducationDetailsDTO> GetEducationDetails(@PathVariable Long id)
	{
		return new ResponseEntity<EducationDetailsDTO>(educationServices.getEducationDetails(id),HttpStatus.ACCEPTED);
	}
}
