package com.example.demo.ServiceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Entities.EducationDetails;
import com.example.demo.Proxies.EducationDetailsDTO;
import com.example.demo.Repositories.EducationDetailsRepo;
import com.example.demo.Services.EducationDetailsServices;
import com.example.demo.Utils.ObjectMapperHelper;

@Component
public class EducationDetailsServicesImpl implements EducationDetailsServices{

	
	
	@Autowired
	private ObjectMapperHelper helper;
	
	@Autowired
	private EducationDetailsRepo repo;
	
	@Override
	public String addEducationDetail(EducationDetailsDTO educationDetailsDTO) {

		EducationDetails educationDetails = helper.EducationDetailsDtoToEntity(educationDetailsDTO);
		
		repo.save(educationDetails);
		
		return "Data saved Successfuly";
	
	}

	@Override
	public String updateEducationDetails(EducationDetailsDTO educationDetailsDTO) {


		Optional<EducationDetails> byId = repo.findById(educationDetailsDTO.getId());
		
		if(byId.isPresent())
		{
			EducationDetails educationDetails=new EducationDetails(educationDetailsDTO.getId(), educationDetailsDTO.getStudent_enrollmentNo(),
																	educationDetailsDTO.getEducationType(),educationDetailsDTO.getPercentage(),
																	educationDetailsDTO.isQualified(), educationDetailsDTO.getUpdatedBy(),
																	educationDetailsDTO.getUpdateDate());
		
			repo.save(educationDetails);		
			
			return "Updated Successfully";
					
		}
		
		return null;
		
		
		
	}

	@Override
	public EducationDetailsDTO getEducationDetails(Long id) {

		Optional<EducationDetails> byId = repo.findById(id);
		
		if(byId.isPresent())
		{
			EducationDetails educationDetails = byId.get();
			
			return helper.EducationDetailsEntityToDto(educationDetails);
		}
		return null;
	}

}
