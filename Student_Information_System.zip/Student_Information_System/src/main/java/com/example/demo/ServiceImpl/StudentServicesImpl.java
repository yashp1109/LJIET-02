package com.example.demo.ServiceImpl;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Entities.Student;
import com.example.demo.Proxies.StudentDTO;
import com.example.demo.Repositories.StudentRepo;
import com.example.demo.Services.StudentServices;
import com.example.demo.Utils.ObjectMapperHelper;

@Component
public class StudentServicesImpl implements StudentServices {

	@Autowired
	private ObjectMapperHelper obj;
	
	@Autowired
	private StudentRepo repo;
	
	@Override
	public String UserRegistration(StudentDTO studentDTO) {


		Student student=obj.StudentDtoToEntity(studentDTO);
		
		repo.save(student);
		
		return "Student Added Successfully";
		
		
	}

	@Override
	public String updateUser(StudentDTO studentDTO) {

		Optional<Student> byId = repo.findById(studentDTO.getEnrollmentNo());
		
		if(byId.isPresent())
		{
			Student student=new Student(studentDTO.getEnrollmentNo(),studentDTO.getPassword(),studentDTO.getName(),
					studentDTO.getGender(),studentDTO.getDob(),studentDTO.getBranch(),studentDTO.getContact(),
					studentDTO.getAddress(),studentDTO.getCity(),studentDTO.getPinCode(),studentDTO.getSecurityKey(),studentDTO.getRole());
			
			return "Updated Successfully";
		}
		
		return null;
	}

	@Override
	public StudentDTO getUser(String rollno) {
		
		Student student = repo.findById(rollno).get();
		
		return obj.StudentEntityToDto(student);
		
	}

}
