package com.example.demo.Services;

import org.springframework.stereotype.Service;

import com.example.demo.Proxies.StudentDTO;

@Service
public interface StudentServices {

	public String UserRegistration(StudentDTO studentDTO);
	
	public String updateUser(StudentDTO studentDTO);
	
	public StudentDTO getUser(String rollno);
}
