package com.example.demo.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Entities.Administartor;
import com.example.demo.Entities.Student;
import com.example.demo.Proxies.AdministartorDTO;
import com.example.demo.Proxies.StudentDTO;
import com.example.demo.Repositories.AdministartorRepo;
import com.example.demo.Repositories.StudentRepo;
import com.example.demo.Services.AdministartorServices;
import com.example.demo.Utils.ObjectMapperHelper;

@Component
public class AdministartorServicesImpl implements AdministartorServices {

	@Autowired
	private AdministartorRepo Adminrepo;
	
	@Autowired
	private StudentRepo studentRepo;
	
	@Autowired
	private ObjectMapperHelper helper;


	
	@Override
	public String  AdminRegistration(AdministartorDTO administartorDTO)
	{
		Administartor administartor= helper.AdministratorDtoToEntity(administartorDTO);
		
		Adminrepo.save(administartor);
		
		return "Admin Registration Successfully";
	}

	@Override
	public String UpdateAdmin(AdministartorDTO admin)
	{

		Optional<Administartor> byId = Adminrepo.findById(admin.getId());
		
		if(byId.isPresent())
		{

			Administartor Admin=new Administartor(admin.getId(),admin.getPassword(),admin.getName(),admin.getGender(),
												admin.getContact(),admin.getAddress(),admin.getCity(),admin.getPinCode(),
												admin.getSecurityKey(),admin.getRole());
			Adminrepo.save(Admin);
			return "Updated Successfully";
		}
		return null;
		
	}

	@Override
	public AdministartorDTO getAdmin(Long id) {

		Administartor byId = Adminrepo.findById(id).get();
		
		return helper.AdministratorEntityToDto(byId);
	}

	@Override
	public String deleteUserById(String Id) {
		
		if(studentRepo.findById(Id).isPresent())
		{
			
			studentRepo.deleteById(Id);
			
			return "Deleted Successfully";
		}
		
		return null;
	}

	@Override
	public List<StudentDTO> getAllUser() {


		List<Student> students = studentRepo.findAll();
		
		List<StudentDTO> dtoList=new ArrayList<>();
		
		for(Student student:students)
		{
			StudentDTO dto=new StudentDTO(student.getEnrollmentNo(),student.getPassword(),
					student.getName(),student.getGender(),student.getDob(),student.getBranch(),
					student.getContact(),student.getAddress(),student.getCity(),
					student.getPinCode(),student.getSecurityKey(),student.getRole());
			
			dtoList.add(dto);
		}
		return dtoList;
		
	}
	
}
