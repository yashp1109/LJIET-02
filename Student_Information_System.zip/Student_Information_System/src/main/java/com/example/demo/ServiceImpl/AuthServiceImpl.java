package com.example.demo.ServiceImpl;

import org.springframework.stereotype.Component;

import com.example.demo.Services.AuthService;

@Component
public class AuthServiceImpl implements AuthService{

}
