package com.movie.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor //(staticName = "statimoviedto")
public class MovieDto {
	private Long id;
	
	private String moviename;
	
	private String movietype;
	
	private List<ProducerDto> producer;
}
