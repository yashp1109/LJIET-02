package com.movie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.movie.dto.MovieDto;
import com.movie.service.ServiceMovie;

@RestController

public class Controller {

	@Autowired
	private ServiceMovie serviceMovie;
	
	@PostMapping("/Save-Movie")
	public ResponseEntity<String> savemovie(@RequestBody MovieDto movieDto)
	{
		return new ResponseEntity<String>(serviceMovie.savemovie(movieDto),HttpStatus.ACCEPTED);
	}
	
	
	@GetMapping("/Get-AllMovie")
	public ResponseEntity<List<MovieDto>> getallmovie()
	{
		return new ResponseEntity<List<MovieDto>>(serviceMovie.getallmovie(),HttpStatus.OK);
	}
	
	
	@GetMapping("/Get-Movie/{id}")
	public ResponseEntity<MovieDto> getmoviebyid(@PathVariable Long id)
	{
		return new ResponseEntity<MovieDto>(serviceMovie.getmoviebyid(id),HttpStatus.ACCEPTED);
	}
	
	
	@PutMapping("/Update-Movie/{id}")
	public ResponseEntity<String> updatemovie(@PathVariable Long id, @RequestBody MovieDto movieDto)
	{
		return new ResponseEntity<String>(serviceMovie.updatemovie(id, movieDto),HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping("/Delete-Movie/{id}")
	public String Deletemovie(@PathVariable Long id) {
		return serviceMovie.deletemovie(id);
	}
	
	@DeleteMapping("/Delete-AllMovie")
	public String Deleteallmovie() {
		return serviceMovie.deleteallmovie();
	}
}
