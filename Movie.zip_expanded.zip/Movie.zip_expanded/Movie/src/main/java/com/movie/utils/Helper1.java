package com.movie.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie.dto.MovieDto;
import com.movie.entity.MovieEntity;

@Component
public class Helper1 {

		@Autowired
		private ObjectMapper objectMapper;
		
		public MovieEntity dtotoentity(MovieDto movieDto) {
			return objectMapper.convertValue(movieDto,MovieEntity.class);
		}
		
		
		public MovieDto entitytodto(MovieEntity movieEntity) {
			return objectMapper.convertValue(movieEntity,MovieDto.class);
		}
		
}


