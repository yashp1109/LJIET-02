package com.movie.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.movie.dto.MovieDto;

@Service
public interface ServiceMovie {
	
	public String savemovie(MovieDto movieDto);
	
	public List<MovieDto> getallmovie();
	
	public MovieDto getmoviebyid(Long id);
	
	public String updatemovie(Long id, MovieDto movieDto);

	public String deletemovie(Long id);

	public String deleteallmovie();

}
