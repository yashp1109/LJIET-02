package com.movie.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Data
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor //(staticName = "statiproducerentity")

@JsonInclude(Include.NON_NULL)
public class ProducerEntity {
@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Id
	private Long pro_id;
	
	private String pro_name;

	private String pro_city;
	
	@ManyToOne(cascade = CascadeType.ALL,targetEntity = MovieEntity.class)
//	@JsonBackReference

	private List<MovieEntity> movieEn;
	
}
