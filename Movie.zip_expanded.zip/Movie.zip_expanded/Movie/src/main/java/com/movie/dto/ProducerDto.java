package com.movie.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor //(staticName = "statiproducerdto")

public class ProducerDto {
	private Long pro_id;
	
	private String pro_name;
	
	private String pro_city;
	
	private List<MovieDto>  movieEn;
}
