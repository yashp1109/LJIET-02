package com.movie.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.movie.dto.MovieDto;
import com.movie.entity.MovieEntity;
import com.movie.repo.RepoMovie;
import com.movie.service.ServiceMovie;
import com.movie.utils.Helper1;

@Component
public class MovieImpl implements ServiceMovie {

	
	@Autowired
	private RepoMovie repoMovie;
	
	@Autowired
	private Helper1 helper;
	
/****************************** Save-Movie ******************************/
	
	@Override
	public String savemovie(MovieDto movieDto) {
	MovieEntity movieEntity =helper.dtotoentity(movieDto);
	//ProducerEntity producerEntity = helper.dtotoproEntity(movieDto)
	 repoMovie.save(movieEntity);
	 System.out.println("data"+movieEntity);
		return "Data Saved Successfully";
	}

/****************************** Get-AllMovie ******************************/
	
	@Override
	public List<MovieDto> getallmovie() { 
		
		List<MovieDto> movieDtos = new ArrayList<>();
		List<MovieEntity> movieEntities = (List<MovieEntity>)repoMovie.findAll();
		for(MovieEntity entity : movieEntities) {
			MovieDto movieDto = helper.entitytodto(entity);
			movieDtos.add(movieDto);
		}
	
		return movieDtos;
	}

/****************************** Get-Movie ******************************/
	
	@Override
	public MovieDto getmoviebyid(Long id) {
		MovieEntity movieEntity= repoMovie.findById(id).get();
		MovieDto movieDto = helper.entitytodto(movieEntity);
		return movieDto;
	}

/****************************** Update-Movie ******************************/
	
	@Override
	public String updatemovie(Long id, MovieDto movieDto) {
		Optional idfin = repoMovie.findById(id);
		if(idfin.isPresent()){
			
			MovieEntity movieEntity = helper.dtotoentity(movieDto);
			repoMovie.save(movieEntity);
			return "Data is Successfully Update";
		}
		else {
			return "Data is not found";
		}
		
	}
	
/****************************** Delete-Movie ******************************/
	
	@Override
	public String deletemovie(Long id) {
		repoMovie.deleteById(id);
		return "Delete Successfully";
	}
	
/****************************** Delete-AllMovie ******************************/
	
	@Override
	public String deleteallmovie() {
		repoMovie.deleteAll();
		return "Data is remove Successfully";
	}
}
