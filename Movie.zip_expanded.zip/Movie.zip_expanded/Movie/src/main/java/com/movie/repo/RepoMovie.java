package com.movie.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.movie.entity.MovieEntity;

@Repository
public interface RepoMovie extends CrudRepository<MovieEntity, Long>{

}
