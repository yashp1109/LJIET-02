package com.movie.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.movie.entity.ProducerEntity;
@Repository
public interface RepoProducer extends CrudRepository<ProducerEntity, Long> {

}
