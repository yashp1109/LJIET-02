package com.emp.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
//@Table(name = "Employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "emp_id")
	private long empid;
	
	@Column(name = "emp_name")
	private String empname;
	
	@Column(name = "emp_city")
	private String empcity;
	
	@Column(name = "emp_salary")
	private long empsalary;
	
//	@OneToOne(cascade = CascadeType.ALL)
//	Laptop l1;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<EmployeeAddress> empadd;
	
}
