package com.emp.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class employeedto {
		
	private long empid;
	private String empname;
	private String empcity;
	private long empsalary;
	
//	private laptopdto ldto;
	
	private List<EmployeeAddressdto> empadddto;
	
	}
