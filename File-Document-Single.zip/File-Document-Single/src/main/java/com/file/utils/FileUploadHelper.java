package com.file.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.file.entity.File;
import com.file.respository.StorageRespository;

@Component
public class FileUploadHelper {
	
	@Autowired
	private StorageRespository repoRespository;
	
	public static ObjectMapper mapper;
	
//	public final String UPLOAD_DIR="C:\\Users\\JayrajThummar\\Documents\\workspace-spring-tool-suite-4-4.21.0.RELEASE\\File-Uploading\\src\\main\\resources\\static\\image";

	public final String UPLOAD_DIR=new ClassPathResource("static/image").getFile().getAbsolutePath();
	
	public FileUploadHelper() throws IOException {
		
	}
	
	public String uploadFile(MultipartFile multipartFile)
	{
		
		try {
			
			Files.copy(multipartFile.getInputStream(), Paths.get(UPLOAD_DIR+"//"+multipartFile.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
			 
			File data= File.builder().name(multipartFile.getOriginalFilename()).type(multipartFile.getContentType()).imageData(multipartFile.getBytes()).build();
			
			repoRespository.save(data);
			return "Uploaded Successfully";
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
			return "File not found";
		}
			
	}
	
	public byte[] downloadImage(String file)
	{
		Optional<File> dbImageData = repoRespository.findByName(file);
		
		byte[] images=dbImageData.get().getImageData();
		return images;
	}
}
