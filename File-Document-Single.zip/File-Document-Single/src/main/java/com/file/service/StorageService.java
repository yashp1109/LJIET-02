package com.file.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@Component
public interface StorageService {
	
	 public String saveImage(MultipartFile file); 
	 
	 public byte[] downloadimage(String file);
	

}
