package com.file.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.file.respository.StorageRespository;
import com.file.service.StorageService;
import com.file.utils.FileUploadHelper;

@Component
public class serviceImpl implements StorageService {

 @Autowired
 private FileUploadHelper helper;
 
 @Autowired
 private StorageRespository repoRespository;
	
	@Override
	public String saveImage(MultipartFile file) 
	{
		return helper.uploadFile(file);
	}

	@Override
	public byte[] downloadimage(String file) 
	{	
		return helper.downloadImage(file);
	}
}
