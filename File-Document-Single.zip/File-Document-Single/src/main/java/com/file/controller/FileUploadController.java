package com.file.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.file.dto.FileDTO;
import com.file.service.StorageService;

@RestController
public class FileUploadController {

	
	@Autowired
	private StorageService service;
	 
	@PostMapping("uploadimage")
	public ResponseEntity<String> uploadImage(@RequestParam("key") MultipartFile file) throws IOException 
	{
		return new ResponseEntity<String>(service.saveImage(file),HttpStatus.OK);
	}
	
	@GetMapping("downloadimage/{image}")
	public ResponseEntity<?> downloadImage(@PathVariable ("image") String file ) throws IOException 
	{
		return  (ResponseEntity<?>)ResponseEntity.status(HttpStatus.OK)
				.contentType(MediaType.MULTIPART_FORM_DATA)
				.body(service.downloadimage(file));
		
//		byte[] imageData=service.downloadimage(file);
//		return (ResponseEntity<?>) ResponseEntity.status(HttpStatus.OK)
//				.contentType(MediaType.valueOf("image/jpeg"))
//				.body(imageData);
	}

}
	
