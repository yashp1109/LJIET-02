package com.example.demo.Proxies;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FeeDetailsDTO {

	private long id;
	
	private String student_enrollmentNo;
	
	private double feeAmount;
	
	private Date dueDate;
	
	private String updatedBy;
 
	private Date updatedDate;
}
