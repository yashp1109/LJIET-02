package com.example.demo.ServiceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Entities.Administartor;
import com.example.demo.Proxies.AdministartorDTO;
import com.example.demo.Repositories.AdministartorRepo;
import com.example.demo.Services.AdministartorServices;
import com.example.demo.Utils.ObjectMapperHelper;

@Component
public class AdministartorServicesImpl implements AdministartorServices {

	@Autowired
	private AdministartorRepo Adminrepo;
	
//	@Autowired
//	private StudentRepo studentRepo;
	
	@Autowired
	private ObjectMapperHelper helper;


	
	@Override
	public String  AdminRegistration(AdministartorDTO administartorDTO)
	{
		Administartor administartor= helper.AdministratorDtoToEntity(administartorDTO);
		
		Adminrepo.save(administartor);
		
		return "Admin Registration Successfully";
	}

	@Override
	public String UpdateAdmin(AdministartorDTO admin)
	{

		Optional<Administartor> byId = Adminrepo.findById(admin.getId());
		
		if(byId.isPresent())
		{

			Administartor Admin=new Administartor(admin.getId(),admin.getPassword(),admin.getName(),admin.getGender(),
												admin.getContact(),admin.getAddress(),admin.getCity(),admin.getPinCode(),
												admin.getSecurityKey(),admin.getRole());
			Adminrepo.save(Admin);
			return "Updated Successfully";
		}
		return null;
		
	}

	@Override
	public AdministartorDTO getAdmin(Long id) {

		Administartor byId = Adminrepo.findById(id).get();
		
		return helper.AdministratorEntityToDto(byId);
	}




	
}
