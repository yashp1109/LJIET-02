package com.example.demo.Controllers;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Proxies.AdministartorDTO;
import com.example.demo.Proxies.FeeDetailsDTO;
import com.example.demo.Services.AdministartorServices;
import com.example.demo.Services.FeeDetailsServices;

@RestController
@RequestMapping("/admin")
public class AdministrativeController<StudentDTO> {

	@Autowired
	private AdministartorServices adminService;
	
	@Autowired
	private FeeDetailsServices feeDetailsServices;
	
	@Autowired
	private RestTemplate restTemplate;
	
//	@Autowired
//	private StudentServices studentServices;
//	
//	@Autowired
//	private EducationDetailsServices educationServices;
	
	// *************************************** Signup API **********************************************	
	
	@PostMapping("/register")
	public ResponseEntity<String> registerWithDetails(@RequestHeader Map<String, String> headerdata,@RequestBody AdministartorDTO administartorDTO)
	{
		try {
			
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
					System.err.println("Hii");
					return new ResponseEntity<String> (adminService.AdminRegistration(administartorDTO),HttpStatus.ACCEPTED);
				}
		
			
		}
			catch (Exception e)
			{
				return ResponseEntity.ok("You are not Authorized..!");
			}
			

			return null;
	}

	// *************************************** Update User API **********************************************		
	
	@PostMapping("/updateUser")
	public ResponseEntity<String> updateUserDetails(@RequestHeader Map<String, String> headerdata ,@RequestBody StudentDTO studentDTO)
	{
		try {
			
		
		HttpHeaders httpHeaders = new HttpHeaders();
		
		httpHeaders.set("Authorization", headerdata.get("token"));
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
 
		System.out.println(httpHeaders);
		HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
		
		
		
		if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) {
			 
			return ResponseEntity.ok(restTemplate.postForObject("http://SERVICE-USER/service-user/user/updateUser", studentDTO, String.class));
		}
		
		} 
		catch (Exception e)
		{
			return ResponseEntity.ok("You are not Authorized..!");
		}
		

		return null;

		
	}
	
	// *************************************** Update Admin API **********************************************	
	
	@PostMapping("/updateAdmin")
	public ResponseEntity<String> updateAdminDetails(@RequestHeader Map<String, String> headerdata ,@RequestBody AdministartorDTO administartorDTO)
	{
		try {
			
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
					return new ResponseEntity<String> (adminService.UpdateAdmin(administartorDTO),HttpStatus.ACCEPTED);
				}
					
		}
	catch (Exception e)
	{
		return ResponseEntity.ok("You are not Authorized..!");
	}
	

	return null;
	}
	
	// *************************************** Delete User API **********************************************	
	
	@PostMapping("/deleteUser/{enrollmentNo}")
	public ResponseEntity<String> deleteUser(@RequestHeader Map<String, String> headerdata ,@PathVariable String enrollmentNo)
	{

		try {
			
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
		
				String forObject = restTemplate.postForObject("http://SERVICE-USER/service-user/user/deleteUser/"+enrollmentNo,enrollmentNo, String.class);
				return new ResponseEntity<String>(forObject,HttpStatus.ACCEPTED);
				}
		
			
		}
			catch (Exception e)
			{
				return ResponseEntity.ok("You are not Authorized..!");
			}
			

			return null;
	}
	
	// *************************************** Get All Users API **********************************************	
	
	@SuppressWarnings("unchecked")
	@GetMapping("/getAllUser")
	public ResponseEntity<Object> getUsers(@RequestHeader Map<String, String> headerdata)
	{
		try {
			
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
					ArrayList<StudentDTO> forObject = restTemplate.getForObject("http://SERVICE-USER/service-user/user/getAllUser",ArrayList.class);
					return new ResponseEntity<Object>(forObject,HttpStatus.ACCEPTED);
				}
		
		}
			catch (Exception e)
			{
				return ResponseEntity.ok("You are not Authorized111..!");
			}
			

			return null;
		

	}
	
	// *************************************** Get User API **********************************************	
	
	@GetMapping("/getUser/{enrollmentNo}")
	public ResponseEntity<Object> getUser(@RequestHeader Map<String, String> headerdata ,@PathVariable String enrollmentNo)
	{
		try {
			
			System.err.println("Hii");
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
					System.err.println("Hello");
					Object forObject = restTemplate.getForObject("http://SERVICE-USER/service-user/user/getUserFromAdmin/"+enrollmentNo, Object.class);
	
					return new ResponseEntity<Object>(forObject,HttpStatus.ACCEPTED);}

			}
		catch (Exception e)
		{
			return ResponseEntity.ok("You are not Authorized..!");
		}
				

		return null;
	}
	
	// *************************************** Get Admin API **********************************************	
	
	@GetMapping("/getAdmin/{id}")
	public ResponseEntity<Object> getAdmin(@RequestHeader Map<String, String> headerdata ,@PathVariable("id") Long id)
	{
		try {
			
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
						return new ResponseEntity<Object>(adminService.getAdmin(id),HttpStatus.ACCEPTED);
				}
			
			
		}
		catch (Exception e)
		{
			return ResponseEntity.ok("You are not Authorized..!");
		}
	

		return null;
	}
	
	// *************************************** Add FeeDetails API **********************************************	
	
	@PostMapping("/addFeeDetails")
	public ResponseEntity<String> addFeeDetails(@RequestHeader Map<String, String> headerdata ,@RequestBody FeeDetailsDTO feeDetailsDTO)
	{
		try {
		
		
		HttpHeaders httpHeaders = new HttpHeaders();
		
		httpHeaders.set("Authorization", headerdata.get("token"));
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
 
		System.out.println(httpHeaders);
		HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
		
		if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
			{
		return new ResponseEntity<String>(feeDetailsServices.addFeeDetails(feeDetailsDTO),HttpStatus.ACCEPTED);}
		
			
		}
			catch (Exception e)
			{
				return ResponseEntity.ok("You are not Authorized..!");
			}
			

			return null;
	}
	
	// *************************************** Get FeeDetails API **********************************************
	
	@GetMapping("/getFeeDetails/{id}")
	public ResponseEntity<Object> getFeeDetails(@RequestHeader Map<String, String> headerdata ,@PathVariable Long id)
	{
		try {
			
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
					return new ResponseEntity<Object>(feeDetailsServices.getFeeDetails(id),HttpStatus.ACCEPTED);
					
				}
			
			
			}
		catch (Exception e)
		{
			return ResponseEntity.ok("You are not Authorized..!");
		}
				

		return null;
	}
	
	// *************************************** Get EducationDetails API **********************************************
	
	@GetMapping("/getEducationDetails/{id}")
	public ResponseEntity<Object> GetEducationDetails(@RequestHeader Map<String, String> headerdata ,@PathVariable Long id)
	{
		try {
			
			
			HttpHeaders httpHeaders = new HttpHeaders();
			
			httpHeaders.set("Authorization", headerdata.get("token"));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	 
			System.out.println(httpHeaders);
			HttpEntity<Object> httpEntity = new HttpEntity<Object>(null, httpHeaders);
			
			if (restTemplate.postForEntity("http://SERVICE-AUTH/service-auth/auth/validate", httpEntity, Object.class).getBody().equals(true)) 
				{
					Object forObject = restTemplate.getForObject("http://SERVICE-USER/service-user/user/getEducationDetails/"+id, Object.class);
	
					return new ResponseEntity<Object>(forObject,HttpStatus.ACCEPTED);
				}
					
			}
			catch (Exception e)
			{
				return ResponseEntity.ok("You are not Authorized..!");
			}
			

			return null;
		
	
	}
}
