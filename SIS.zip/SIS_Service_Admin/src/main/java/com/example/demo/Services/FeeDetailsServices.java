package com.example.demo.Services;

import org.springframework.stereotype.Service;

import com.example.demo.Proxies.FeeDetailsDTO;

@Service
public interface FeeDetailsServices {

	public FeeDetailsDTO getFeeDetails(Long id);
	
	public String addFeeDetails(FeeDetailsDTO feeDetailsDTO);
}
