package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.Proxy.RegistrationDTO;

@Service
public interface RegistrationService {
	
	public String registerData(RegistrationDTO registrationDTO);
}
