package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.entities.Registration;

public interface RegistrationRepo extends CrudRepository<Registration, Long> {

	

}
