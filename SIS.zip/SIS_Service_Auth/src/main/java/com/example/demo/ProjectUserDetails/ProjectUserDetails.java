package com.example.demo.ProjectUserDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.entities.CustomAdministrator;
import com.example.demo.entities.CustomUser;
import com.example.demo.entities.Registration;
import com.example.demo.entities.Role;
import com.example.demo.repo.RegistrationRepo;

@Service
public class ProjectUserDetails implements UserDetailsService{


	
	@Autowired
	private RegistrationRepo repo;
	

	
	private String role;
	
	public void setRole(String role) {
		// TODO Auto-generated method stub
		this.role = role;
	}
	
	
	@Override
	public UserDetails loadUserByUsername(String rollno){

		
		if (role.equals(Role.ROLE_ADMIN.toString())) {

	 
			Registration admin = repo.findById(Long.parseLong(rollno)).get();
	 
				if (admin != null) {
			
					return new CustomAdministrator(admin);
				} else {
					throw new UsernameNotFoundException("Admin name is invalid");
				}
	 
			}
		
		else if(role.equals(Role.ROLE_USER.toString())) {

			Registration user = repo.findById(Long.parseLong(rollno)).get();
	 
				if (user != null) {
					
					return new CustomUser(user);
					
				} 
				else 
				{
					throw new UsernameNotFoundException("User name is invalid");
				}
	 
			}
	 
	else {
		System.out.println("Select Your Role Propurly..!!");
		return null;
	}
	 
	}

	

	

}
