package com.example.demo.Utils;

import org.springframework.stereotype.Component;

import com.example.demo.Proxy.RegistrationDTO;
import com.example.demo.entities.Registration;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class ObjectMapperHelper {

	public Registration  DtoToEntity (RegistrationDTO registrationDTO)
	{
		ObjectMapper objectMapper=new ObjectMapper();
		
		return objectMapper.convertValue(registrationDTO,Registration.class);
	}
	
	public RegistrationDTO  DtoToEntity (Registration registration)
	{
		ObjectMapper objectMapper=new ObjectMapper();
		
		return objectMapper.convertValue(registration,RegistrationDTO.class);
	}
	
}
