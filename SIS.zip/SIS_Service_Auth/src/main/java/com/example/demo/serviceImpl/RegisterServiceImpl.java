package com.example.demo.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Proxy.RegistrationDTO;
import com.example.demo.Utils.ObjectMapperHelper;
import com.example.demo.repo.RegistrationRepo;
import com.example.demo.service.RegistrationService;

@Component
public class RegisterServiceImpl implements RegistrationService{

	@Autowired
	RegistrationRepo repo;
	
	@Autowired
	ObjectMapperHelper helper;
	
	public String registerData(RegistrationDTO registrationDTO)
	{
		repo.save(helper.DtoToEntity(registrationDTO));
		
		return "Register Sucessfully";
	}
	
}
