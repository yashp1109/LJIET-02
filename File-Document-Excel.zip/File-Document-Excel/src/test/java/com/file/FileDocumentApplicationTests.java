package com.file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileDocumentApplicationTests {

	@Test
	void contextLoads() {
	}

}
