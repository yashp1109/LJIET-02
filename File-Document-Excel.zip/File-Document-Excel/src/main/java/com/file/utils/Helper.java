package com.file.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.file.dto.ProductDTO;
import com.file.entity.Product;
import com.file.repo.ProductRepo;

@Component
public class Helper {
	
	@Autowired
	private static ProductRepo productRepo;
	
	static ObjectMapper obj=new ObjectMapper();
	
	
/****************************** Import Data From Excel to DB Table ******************************/
	//Convert excel to list of Document
	public static List<Product> UploadExcel(InputStream inputStream)
	{
		List<Product> list = new ArrayList<>();
		
		try {
			
			//Create workBook using XSSFWorkbook
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			
			//Create sheet
			XSSFSheet sheet =  workbook.getSheet("Data");
			
			int rowNumber=0;
			
			//Creating object of Rows
			Iterator<Row> iterator = sheet.iterator();
			
			while (iterator.hasNext()) 
			{
				Row row = iterator.next();
				
				if (rowNumber==0) 
				{
					rowNumber++;
					continue;
				}	
				Iterator<Cell> cells = row.iterator();
				
				int cid=0;
				
				Product product = new Product();
				
				while (cells.hasNext())
				{
					Cell cell = cells.next();
					
					switch(cid)
					{	
						case 0:
							product.setName(cell.getStringCellValue());
							break;
						case 1:
							product.setPrice((long)cell.getNumericCellValue());
							break;
						case 2:
							product.setCity(cell.getStringCellValue());
							break;
						default:
							break;	
					}
					cid++;	
				}
				
				list.add(product);
			}
				
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
/****************************** Get All Data from DB Table in JSON ******************************/	
	public static List<ProductDTO> getallproduct()
	{
		List<Product> list = productRepo.findAll();
		
		List<ProductDTO> dtoList=new ArrayList<>();
		
		for(Product product:list)
		{
			ProductDTO convertValue = obj.convertValue(product,ProductDTO.class);
			dtoList.add(convertValue);
		}
		return dtoList;
	}
	
	
/****************************** Export Data From DB Table to Excel and Download the same ******************************/
	
	public static String[] HEADERS= {
			"name",
			"price",
			"city"
	};
	
	public static String SHEET_NAME="Data";
	
	
	public static ByteArrayInputStream dataToExcel(List<ProductDTO> list) throws IOException
	{
		//Create work book
		Workbook workbook=new XSSFWorkbook();
		
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		
		try {
			
			//Create sheet
			Sheet sheet = workbook.createSheet(SHEET_NAME);
				
			//Create row : header row
			Row row = sheet.createRow(0);
			
			for(int i=0; i < HEADERS.length; i++)
			{
				Cell cell = row.createCell(i);
				cell.setCellValue(HEADERS[i]);
			}
			
			//Value rows
			int rowIndex=1;
			
			for(ProductDTO product : list) 
			{
				Row dataRow = sheet.createRow(rowIndex);
				
				rowIndex++;
				
				dataRow.createCell(0).setCellValue(product.getName());
				dataRow.createCell(1).setCellValue(product.getPrice());
				dataRow.createCell(2).setCellValue(product.getCity());
			}
			
			workbook.write(out);
			
			return new ByteArrayInputStream(out.toByteArray());
		}		
		
		finally
		{
			workbook.close();
			out.close();
		}	
	}
 
	
	//Check that file is of excel type or not
	public static boolean checkExcelFormat(MultipartFile file)
	{
		String contentType = file.getContentType();
		
		if (contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) 
		{
			return true;
		}
		else
			return false;
	}
	
	

	
	

}
