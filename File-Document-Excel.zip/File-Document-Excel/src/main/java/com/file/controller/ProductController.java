package com.file.controller;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.file.dto.ProductDTO;
import com.file.service.ProductService;
import com.file.utils.Helper;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	
/****************************** Import Data From Excel to DB Table ******************************/
	
	@PostMapping("/product/upload")
	public ResponseEntity<?> upload(@RequestParam("file") MultipartFile file)
	{
		if (Helper.checkExcelFormat(file)) 
		{
			productService.save(file);
			return ResponseEntity.ok(Map.of("message","File is Uploaded"));
		}
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please upload excel file only");
	}

	
/****************************** Get All Data from DB Table in JSON ******************************/
	
	@GetMapping("/product")	
	public List<ProductDTO> getAllProducts()
	{
		return productService.getAllProducts();
	}
	

/****************************** Download Excel Sheet Format ******************************/	

	@GetMapping("/excelsheet_format")
	public ResponseEntity<Resource> blankExcel() 
	{
		Resource resource = productService.blankExcel();
		
		HttpHeaders httpHeaders = new HttpHeaders();
		
		httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, "attchment;filename=product.xlsx");
 
		return ResponseEntity.ok().headers(httpHeaders).contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);
 
	}

	
/****************************** Export Data From DB Table to Excel and Download the same ******************************/	

	@GetMapping("/excel_withdata")
	public ResponseEntity<Resource> excelWithData()
	{
		String filename="product.xlsx";
		ByteArrayInputStream actualdata=productService.excelWithData();
		InputStreamResource file=new InputStreamResource(actualdata);
		
		ResponseEntity<Resource> responseEntity = ResponseEntity.ok()
				.header("Content-Disposition", "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
				.body(file);
		
		return responseEntity;
	}
	
	
}
