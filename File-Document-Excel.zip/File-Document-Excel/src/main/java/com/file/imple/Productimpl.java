package com.file.imple;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.file.dto.ProductDTO;
import com.file.entity.Product;
import com.file.repo.ProductRepo;
import com.file.service.ProductService;
import com.file.utils.Helper;

@Component
public class Productimpl implements ProductService {
	
	@Autowired
	private ProductRepo productRepo;
	
	ObjectMapper obj=new ObjectMapper();
	
	
/****************************** Import Data From Excel to DB Table ******************************/
	@Override
	public void save(MultipartFile file)
	{
		try {
			String path = new ClassPathResource("static/upload").getFile().getAbsolutePath();
			
			File f = new File(path);
			
			if(!f.exists())
			{
				f.mkdir();
			}
			
			String fullpath = path +File.separator+file.getOriginalFilename();
			
			Files.copy(file.getInputStream(),Path.of(fullpath),StandardCopyOption.REPLACE_EXISTING);
			
			
			List<Product> products = Helper.UploadExcel(file.getInputStream());
			
			productRepo.saveAll(products);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
/****************************** Get All Data from DB Table in JSON ******************************/
	@Override
	public List<ProductDTO> getAllProducts()
	{
		List<Product> list = productRepo.findAll();
		
		List<ProductDTO> dtoList=new ArrayList<>();
		
		for(Product p:list)
		{
			ProductDTO convertValue = obj.convertValue(p,ProductDTO.class);
			dtoList.add(convertValue);
		}
		return dtoList;
	}


/****************************** Download Excel Sheet Format ******************************/	
	@Override
	public Resource blankExcel() 
	{
		Resource resource = new ClassPathResource("static/excelsheet/product.xlsx");
		return resource;
	}

	
/****************************** Export Data From DB Table to Excel and Download the same ******************************/
	@Override
	public ByteArrayInputStream excelWithData() 
	{
		try {
			return Helper.dataToExcel(getAllProducts());
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
