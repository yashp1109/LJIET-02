package com.file.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.file.dto.ProductDTO;

@Service
public interface ProductService {

	public void save(MultipartFile file);

	public List<ProductDTO> getAllProducts();

	public ByteArrayInputStream excelWithData();

	public Resource blankExcel();

	
}
