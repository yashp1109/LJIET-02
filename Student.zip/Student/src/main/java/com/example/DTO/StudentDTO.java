package com.example.DTO;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString

public class StudentDTO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int rollno;
	
	@NotBlank(message = "Name is mandatory")
	private String name;
	
	@Min(value=1000000000 , message = "Please Entered value is 10 digits...")
	@Max(value=9999999999L , message = "Please Entered value is 10 digits...")
	private long mobileno;
	
	@NotBlank(message = "Address is mandatory")
	private String address;
	
	@Min(value=100000 , message = "Please Entered value is 6 digits...")
	@Max(value=999999L , message = "Please Entered value is 6 digits...")
	private long pincode;

}
