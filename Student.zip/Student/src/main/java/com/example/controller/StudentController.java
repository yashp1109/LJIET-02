package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.DTO.StudentDTO;
import com.example.entity.StudentEntity;
import com.example.service.StudentService;

import jakarta.validation.Valid;


@RestController
public class StudentController {
	
	@Autowired
	private StudentService service;
	
/****************************************   SAVE-STUDENT   ********************************************/
	
	@PostMapping(value= "/save-student1")
	public String saveStudent(@Valid @RequestBody StudentDTO student) {
		return service.saveStudent(student);
	}
	
	
/****************************************   GET-ALLSTUDENT   ********************************************/
	
	@GetMapping("/get-Allstudent1")
	public ResponseEntity<List<StudentDTO>> getAllStudent() {
		return new ResponseEntity<List<StudentDTO>>(service.getAllStudent(),HttpStatus.NOT_FOUND);
	}
	
		
/****************************************   GET-STUDENT   ********************************************/

	@GetMapping("/get-Student/{rollno}")
	public ResponseEntity<StudentDTO> getStudent(@PathVariable int rollno) {
		return new ResponseEntity <StudentDTO>(service.getStudent(rollno),HttpStatus.ACCEPTED);
	}
	
	
/****************************************   UPDATE-STUDENT   ********************************************/
	
	@PutMapping("/Update-student/{rollno}")
	public String updateStudent(@RequestBody StudentEntity student) {
		return service.updateStudent(student);
	}
	
/****************************************   DELETE-STUDENT   ********************************************/
	
	@DeleteMapping("/Delete-student/{rollno}")
	public String deleteStudent(@PathVariable ("rollno") int rollno) {
		return service.deleteStudent(rollno);
	}
	
	
/****************************************   DELETE-ALLSTUDENT   ********************************************/
	
	@DeleteMapping("/Delete-AllStudent")
	public String deleteAllSudent() {
		return service.deleteAllStudent();
	}
	

	
	
}