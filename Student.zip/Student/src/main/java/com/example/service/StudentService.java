package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.service.StudentService;
import com.example.DTO.StudentDTO;
import com.example.entity.StudentEntity;

@Service
public interface StudentService {

	public List<StudentDTO> getAllStudent();

	public String saveStudent(StudentDTO student);

	public String deleteStudent(int rollno);
	
	public String deleteAllStudent();

	public StudentDTO getStudent(int rollno);
	
	public String updateStudent(StudentEntity student);
}
