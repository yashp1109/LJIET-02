package com.example.studentImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.DTO.StudentDTO;
import com.example.entity.StudentEntity;
import com.example.exceptions.CustomException;
import com.example.repository.StudentRepository;
import com.example.service.StudentService;


@Component
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository repo;
	
/****************************************   SAVE-STUDENT   ********************************************/
	
	@Override
	public String saveStudent(StudentDTO student) {
		
		StudentEntity s=new StudentEntity();
		
		s.setRollno(student.getRollno());
		s.setName(student.getName());
		s.setMobileno(student.getMobileno());
		s.setAddress(student.getAddress());
		s.setPincode(student.getPincode());
		
		repo.save(s);
		return "Data has been saved";
	}
	
	
/****************************************   GET-ALLSTUDENT   ********************************************/
	
	@Override
	public List<StudentDTO> getAllStudent() {
		
		List<StudentEntity> allStudents = (List<StudentEntity>) repo.findAll();
		
		if(allStudents.isEmpty()) 
		{
			throw new CustomException("List is Empty","300");
		}
		
		List<StudentDTO> list=new ArrayList<>();
		
		
		for(StudentEntity s : allStudents)
		{
			StudentDTO sdto=new StudentDTO();
			sdto.setRollno(s.getRollno());
			sdto.setName(s.getName());
			sdto.setMobileno(s.getMobileno());
			sdto.setAddress(s.getAddress());
			sdto.setPincode(s.getPincode());
			
			list.add(sdto);
		}
		
		return list;
	}
	

/****************************************   GET-STUDENT   ********************************************/
	
	public StudentDTO getStudent(int rollno)
	{
		if(repo.findById(rollno).isEmpty()) 
		{
			throw new CustomException("Id is not available","200");
		}
		
		StudentEntity getstudent = repo.findById(rollno).get();
		
		StudentDTO s1=new StudentDTO();
		s1.setRollno(getstudent.getRollno());
		s1.setName(getstudent.getName());
		s1.setMobileno(getstudent.getMobileno());
		s1.setAddress(getstudent.getAddress());
		s1.setPincode(getstudent.getPincode());
		
		return s1;
	}
	
	
/****************************************   UPDATE-STUDENT   ********************************************/

	public String updateStudent(StudentEntity student)
	{
		Optional<StudentEntity> update= repo.findById(student.getRollno());
		
		if(update.isPresent())
		{
			StudentEntity x=update.get();
			x.setName(student.getName());
			x.setMobileno(student.getMobileno());
			x.setAddress(student.getAddress());
			x.setPincode(student.getPincode());
			
			repo.save(x);
			
			return "Data is Successfully Update";
		}
		
		return "Data Not Found";
	}
	
	
/****************************************   DELETE-STUDENT   ********************************************/
	
	public String deleteStudent(int rollno)
	{
		if(repo.findById(rollno).isEmpty()) 
		{
			throw new CustomException("Id is not available","300");
		}
		repo.deleteById(rollno);
		return "Delete Successfully";
	}
	
	
/****************************************   DELETE-ALLSTUDENT   ********************************************/
	
	public String deleteAllStudent()
	{
		List<StudentEntity> allStudents = (List<StudentEntity>) repo.findAll();
		
		if(allStudents.isEmpty()) 
		{
			throw new CustomException("List is Empty","300");
		}
		
		repo.deleteAll();
		return "All Data Remove";
	}
	
	

}
