package com.example.exceptions;

import java.util.Date;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class GlobalExceptionHandler {
	
	Date date = new Date(); 
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<FormatException> exceptionThird(Exception e) 
	{	
		return new ResponseEntity<FormatException>(new FormatException("Follow Format", "5000",date.toString()),HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity<?> exceptionFour(NoSuchElementException e)
	{
		FormatException exception = new FormatException("Data not found","1000",date.toString());
		return new ResponseEntity<FormatException> (exception,HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<?> exceptionFirst(HttpRequestMethodNotSupportedException e)
	{
		FormatException exception = new FormatException("Please Valid Request Method","1000",date.toString());
		return new ResponseEntity<FormatException> (exception,HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<FormatException> exceptionSecond(CustomException e) 
	{
		return new ResponseEntity<FormatException>(new FormatException(e.getMessage(), e.getCode(),date.toString()),HttpStatus.BAD_REQUEST);
	}
	
	
}
