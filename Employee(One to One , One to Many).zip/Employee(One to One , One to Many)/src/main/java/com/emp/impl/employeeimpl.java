package com.emp.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.ListableBeanFactoryExtensionsKt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.emp.dto.EmployeeAddressdto;
import com.emp.dto.employeedto;
import com.emp.dto.laptopdto;
import com.emp.entities.Employee;
import com.emp.entities.EmployeeAddress;
//import com.emp.entities.Laptop;
import com.emp.repo.employeerepo;
import com.emp.service.employeeservice;

import lombok.extern.java.Log;

@Component
public class employeeimpl implements employeeservice {
	
	@Autowired
	private employeerepo repo;

/****************************************   SAVE-EMPLOYEE   ********************************************/
	
	/* one to many */
	@Override
	public String saveEmployee(employeedto empdto) {
		
		List<EmployeeAddress> emplist = new ArrayList<>();
		
		List<EmployeeAddressdto> addressdtolist = empdto.getEmpadddto();
		
		for(EmployeeAddressdto empaddressdto : addressdtolist)
		{
			EmployeeAddress empentiAddress = new EmployeeAddress(0l,empaddressdto.getEmpaddname(),empaddressdto.getEmpaddmno());
			
			emplist.add(empentiAddress);
		}
		
			Employee empentity = new Employee(0l,empdto.getEmpname(),empdto.getEmpcity(),empdto.getEmpsalary(),emplist);
			
			repo.save(empentity);
			
			return "Data Save Successfully";
	}
	
/* one to one 
	@Override
	public String saveEmployee(employeedto empdto) {
		Laptop l1=new Laptop(0l,empdto.getLdto().getLaptopname(),empdto.getLdto().getLaptopprice(),empdto.getLdto().getLaptopqty());
		
		Employee e1=new Employee(0l,empdto.getEmpname(),empdto.getEmpcity(),empdto.getEmpsalary(),l1);
		
		repo.save(e1);
		return "Data Save Successfully";
	}*/
	
	
/****************************************   GET-ALLEMPLOYEE   ********************************************/
	
	/* one to many */
	@Override
	public List<employeedto> allEmployee() {
		
		List<Employee> entity = (List<Employee>) repo.findAll();
		
		List<employeedto> empdto = new ArrayList<>();
		
		for(Employee emp : entity)
		{
			List<EmployeeAddressdto> empadddto = new ArrayList<>();
			
			for(EmployeeAddress add : emp.getEmpadd())
			{
				EmployeeAddressdto adddto = new EmployeeAddressdto(add.getEmpaddid(),add.getEmpaddname(),add.getEmpaddmno());
				
				empadddto.add(adddto);   
			}
			
			employeedto edto = new employeedto(emp.getEmpid(),emp.getEmpname(),emp.getEmpcity(),emp.getEmpsalary(),empadddto);
			
			empdto.add(edto);
		}
		return empdto;
	}
	
	
	
	/* one to one
	@Override
	public List<employeedto> allEmployee() {
		
		List<Employee> emp = (List<Employee>) repo.findAll();
		
		List<employeedto> e2= new ArrayList<>();
		
		for(Employee e: emp)
		{
			employeedto e1 = new employeedto();
			
			e1.setEmpid(e.getEmpid());
			e1.setEmpname(e.getEmpname());
			e1.setEmpcity(e.getEmpcity());
			e1.setEmpsalary(e.getEmpsalary());
		
			laptopdto l1 = new laptopdto(); 
			
			l1.setLaptopid(e.getL1().getLaptopid());
			l1.setLaptopname(e.getL1().getLaptopname());
			l1.setLaptopprice(e.getL1().getLaptopprice());
			l1.setLaptopqty(e.getL1().getLaptopqty());
			
			e1.setLdto(l1);
			
			e2.add(e1);
			
		}
		return e2;
	} */
	
	
/****************************************   GET-EMPLOYEE   ********************************************/
	
	/* one to many */
	@Override
	public employeedto getEmployee(long empid) {
		
		Employee employee = repo.findById(empid).get();
		
		List<EmployeeAddressdto> empdto = new ArrayList<>();
		
		List<EmployeeAddress> empaddlist = employee.getEmpadd();
		
		for(EmployeeAddress employeeAddress : empaddlist)
		{
			EmployeeAddressdto empadddto = new EmployeeAddressdto(employeeAddress.getEmpaddid(),employeeAddress.getEmpaddname(),employeeAddress.getEmpaddmno());
			
			empdto.add(empadddto);
		}
		
		employeedto edto = new employeedto(employee.getEmpid(),employee.getEmpname(),employee.getEmpcity(),employee.getEmpsalary(),empdto);
		
		return edto;
		
	}
	
	/* one to one
	@Override
	public employeedto getEmployee(Long empid) {
		
		employeedto e1 = new employeedto();
		
		Employee emp =repo.findById(empid).get();
		
		e1.setEmpid(emp.getEmpid());
		e1.setEmpname(emp.getEmpname());
		e1.setEmpcity(emp.getEmpcity());
		e1.setEmpsalary(emp.getEmpsalary());
		
		laptopdto l1 = new laptopdto(); 
		
		l1.setLaptopid(emp.getL1().getLaptopid());
		l1.setLaptopname(emp.getL1().getLaptopname());
		l1.setLaptopprice(emp.getL1().getLaptopprice());
		l1.setLaptopqty(emp.getL1().getLaptopqty());
		
		e1.setLdto(l1);
		
		return e1;
	} */
	
/****************************************   UPDATE-EMPLOYEE   ********************************************/
	
	/* one to many */
	public String updateEmployee(Long empid,employeedto empdto) {
		
		if(repo.findById(empid).isPresent())
		{
			List<EmployeeAddress> addDto = new ArrayList<>();
			
			for(EmployeeAddressdto dto : empdto.getEmpadddto()) 
			{
				EmployeeAddress eaAddress = new EmployeeAddress(dto.getEmpaddid(),dto.getEmpaddname(),dto.getEmpaddmno());
				addDto.add(eaAddress);
			}
			
			Employee emp = new Employee(empid, empdto.getEmpname(), empdto.getEmpcity(), empdto.getEmpsalary(), addDto) ; 
			repo.save(emp);
			
			return "Data Update Successfully";
		}
		
		return "Data not Found";
	}
	
	/* one to one
	@Override
	public String updateEmployee(Long empid, employeedto empDto) {
		
		Employee Allpro=repo.findById(empid).get();
		
		Long lpcom=Allpro.getL1().getLaptopid();
		
		Laptop lp= new Laptop(lpcom,empDto.getLdto().getLaptopname(),empDto.getLdto().getLaptopprice(),empDto.getLdto().getLaptopqty());
		
		Allpro.setEmpname(empDto.getEmpname());
		Allpro.setEmpcity(empDto.getEmpcity());
		Allpro.setEmpsalary(empDto.getEmpsalary());
		Allpro.setL1(lp);
		repo.save(Allpro);
		
		return "Data is upadate";
	} */
	
	
/****************************************   DELETE-EMPLOYEE   ********************************************/
	
	/* one to many */
	@Override
	public String deleteEmployee(Long empid) {
		repo.deleteById(empid);
		return "Delete Successfully";
	}
	
	
	/* one to one
	@Override
	public String deleteEmployee(Long empid) {
		repo.deleteById(empid);
		return "Delete Successfully";
	} */
	
/****************************************   DELETE-ALLEMPLOYEE   ********************************************/
	
	/* one to many */
	@Override
	public String deleteAllEmployee() {
		repo.deleteAll();
		return "Data is remove Successfully";
	}
	
	/* one to one
	@Override
	public String deleteAllEmployee() {
		repo.deleteAll();
		return "Data is remove Successfully";
	} */
	

}
