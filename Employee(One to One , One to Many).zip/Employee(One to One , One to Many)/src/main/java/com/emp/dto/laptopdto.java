package com.emp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class laptopdto {
	
	private long laptopid;
	private String laptopname;
	private long laptopprice;
	private long laptopqty;
	
	

}
