package com.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.emp.dto.employeedto;
import com.emp.service.employeeservice;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
public class employeecontroller {
	
	@Autowired
	private employeeservice service;
		
/****************************************   SAVE-EMPLOYEE   ********************************************/
	
	/* one to many */
	@PostMapping("/Save-Employee")
	public String SaveEmployee(@RequestBody employeedto empdto) {
		return service.saveEmployee(empdto);
	}
	
/* one to one */
/*	@PostMapping("/Save-Employee")
	public String Saveemployee(@RequestBody employeedto employee) {
		return service.saveEmployee(employee);
	} */
	
/****************************************   GET-ALLEMPLOYEE   ********************************************/
	
	/* one to many */
	@GetMapping("/Get-AllEmployee")
	public List<employeedto> GetAllEmployee() {
		return service.allEmployee();
	}
	
	
/* one to one */
/*	@GetMapping("/Get-AllEmployee")
	public List<employeedto> GetAllEmployee() {
		return service.allEmployee();
	} */

/****************************************   GET-EMPLOYEE   ********************************************/
	
	/* one to many */
	@GetMapping("/Get-Employee/{empid}")
	public employeedto getemployee(@PathVariable long empid) {
		return service.getEmployee(empid);
	}

/* one to one */
/*	@GetMapping("/Get-Employee/{empid}")
	public employeedto getemployee(@PathVariable long empid) {
		return service.getEmployee(empid);
	} */
	
/****************************************   UPDATE-EMPLOYEE   ********************************************/
	
	/* one to many */
	@PutMapping("Update-Employee/{empid}")
	public String updateEmployee(@PathVariable Long empid,@RequestBody employeedto empDto)
	{
		return service.updateEmployee(empid, empDto);
	}

/* one to one */
/*	@PutMapping("Update-Employee/{empid}")
	public String updateEmployee(@PathVariable Long empid,@RequestBody employeedto empDto) {
		return service.updateEmployee(empid, empDto);
	} */

/****************************************   DELETE-EMPLOYEE   ********************************************/
	
	/* one to many */
	@DeleteMapping("/Delete-Employee/{empid}")
	public String deleteemployee(@PathVariable long empid) {
		return service.deleteEmployee(empid);
	}

/* one to one */
/*	@DeleteMapping("/Delete-Employee/{empid}")
	public String deleteemployee(@PathVariable long empid) {
		return service.deleteEmployee(empid);
	} */
	
/****************************************   DELETE-AllEMPLOYEE   ********************************************/
	
	/* one to many */
	@DeleteMapping("/Delete-AllEmployee")
	public String deleteallemployee() {
		return service.deleteAllEmployee();
	}

/* one to one */
/*	@DeleteMapping("/Delete-AllEmployee")
	public String deleteallemployee() {
		return service.deleteAllEmployee();
	} */
	
	
}
	