package com.emp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.emp.dto.employeedto;

@Service
public interface employeeservice {

	/* one to one
	public String saveEmployee(employeedto employee);

	public List<employeedto> allEmployee();

	public employeedto getEmployee(Long empid);

	public String deleteEmployee(Long empid);

	public String deleteAllEmployee();

	public String updateEmployee(Long empid, employeedto empDto); */
	
	
	/* one to many */
	public String saveEmployee(employeedto empdto);

	public List<employeedto> allEmployee();
	
	public employeedto getEmployee(long empid);

	public String deleteEmployee(Long empid);

	public String deleteAllEmployee();
	
	public String updateEmployee(Long empid,employeedto empdto);
	

}
