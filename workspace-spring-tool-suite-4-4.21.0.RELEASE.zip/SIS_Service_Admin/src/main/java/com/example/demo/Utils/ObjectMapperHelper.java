package com.example.demo.Utils;

import org.springframework.stereotype.Component;

import com.example.demo.Entities.Administartor;
import com.example.demo.Entities.FeeDetails;
import com.example.demo.Proxies.AdministartorDTO;
import com.example.demo.Proxies.FeeDetailsDTO;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class ObjectMapperHelper {
	
	
	
	public AdministartorDTO AdministratorEntityToDto(Administartor administartor)
	{
		ObjectMapper obj=new ObjectMapper();
		return obj.convertValue(administartor, AdministartorDTO.class);
	}
	
	public Administartor AdministratorDtoToEntity(AdministartorDTO administartordto)
	{
		ObjectMapper obj=new ObjectMapper();
		return obj.convertValue(administartordto, Administartor.class);
	}

	
	
	
	
	public FeeDetailsDTO FeeDetailsEntityToDto(FeeDetails feeDetails)
	{
		ObjectMapper obj=new ObjectMapper();
		return obj.convertValue(feeDetails,FeeDetailsDTO.class);
	}
	
	public FeeDetails FeeDetailsDtoToEntity(FeeDetailsDTO feeDetailsDTO)
	{
		ObjectMapper obj=new ObjectMapper();
		return obj.convertValue(feeDetailsDTO, FeeDetails.class);
	}
	
	
}
