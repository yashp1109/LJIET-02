package com.example.demo.Services;

import org.springframework.stereotype.Service;

import com.example.demo.Proxies.AdministartorDTO;

@Service
public interface AdministartorServices{

	public String  AdminRegistration(AdministartorDTO administartorDTO);
	
	public String UpdateAdmin(AdministartorDTO admin);
	
	public AdministartorDTO getAdmin(Long id);
	
//	public String deleteUserById(String Id);
	
//	public List<StudentDTO> getAllUser();
}
